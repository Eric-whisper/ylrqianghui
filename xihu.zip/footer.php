
  <link type="text/css" rel="stylesheet" href="./image/index.css">
    <link type="text/css" rel="stylesheet" href="./image/style.css">
<footer class="footer">
    <div class="footer-box">
        <div class="wrap">
            <ul class="footer-ul">
                <li class="aboutYJ">
                    <div class="title">关于艺路人彩绘</div>
                    <div class="split"></div>
                    <ul class="first">
                        <li>
                            <a href="./case.php">经典案例</a>
                        </li>
                        <li>
                            <a href="./zhaopin.php">墙绘招聘</a>
                        </li>
                        <li>
                            <a href="./jiameng.php">加盟我们</a>
                        </li>
                  
                    </ul>
                    <ul>
                        <li>
                            <a href="./jieshao.php">公司介绍</a>
                        </li>
                        <li>
                            <a href="./fengongsi.php">分公司介绍</a>
                        </li>
                        <li>
                            <a href="./contact.php">联系合作</a>
                        </li>
                   
                    </ul>
                </li>
                <li class="contactUs">
                    <div class="title">联系我们</div>
                    <div class="split" style="width: 431px"></div>
                    <div style="margin-top: 26px;width: 400px;margin-left: 102px">
                        <p><span><img src="./image/dianhua.png"></span><span>电话:15093229116</span></p>
                        <p><span><img src="./image/youxiang.png"></span><span>邮箱:515660506@qq.com</span></p>
                        <p><span><img src="./image/dizhi.png"></span><span>地址:上海市奉贤区望园路2509弄2幢101室</span></p>
                    </div>

                </li>

                <li class="erWeiMa">
                    <img src="./image/weixin.jpg" style="margin-left: 43px;margin-top: 85px">
                </li>
            </ul>
        </div>
        <div class="footer_split">
            <hr>
        </div>
        <div class="copy">
            <p class="copyright">
                copyright © 2015 &nbsp; 艺路人彩绘  &nbsp;&nbsp;&nbsp;&nbsp;
            </p>
        </div>
    </div>
</footer>
