<!DOCTYPE html>
<!-- saved from url=(0033)http://www.hnxhqh.com/page-6.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
	<title>上海墙绘,上海艺路人墙绘-合作</title>
	<meta name="keywords" content="上海墙绘,上海艺路人墙绘,上海饭店墙绘,上海幼儿园墙绘">
	<meta name="description" content="艺路人墙绘艺术设计中心主要为高档宾馆酒店,写字楼,幼儿园,古建筑等楼堂馆所进行墙绘工作">
<link href="./css/main.css" rel="stylesheet" type="text/css">
<script src="./js/jQuery1.7.2.js" type="text/javascript"></script>
</head>

<body>
<!-- 头部 开始 -->
<?php
    $page = "hezuo";
 	include "head.php"; 
?>


<!-- 头部 结束 -->
<div class="clear"></div><!-- banner 开始 -->
<div class="fullSlide banner_join"></div>
<!-- banner 结束 -->

<div class="index">
  <div class="mainnav float_left"> 
    <!-- 左侧导航 开始 -->

<!-- 左侧导航 结束 -->

<!-- 左侧轮播 开始 -->
<?php
    include "left.html";
?>
<!-- 左侧轮播 结束 -->

<!-- 联系方式 开始 -->

<!-- 联系方式 结束 --> </div>
  <div class="index_left float_right">
    <div class="main_title"><b>首页 &gt; <span>加盟合作</span></b></div>
    <div class="editor">
        <div class="infotext">
            <img src="https://ylr.oss-cn-beijing.aliyuncs.com/images/join.png">
        </div>
		<div class="infotext">
        	<div class="infotitle">在线留言</div>
            <div class="message_tip"><span>&gt; 我们非常重视您的意见并将在24小时内给您回复</span></div>
            <form action="http://www.hnxhqh.com/index.php?r=GooCms/Form/push" method="post" autocomplete="off">
                <div class="inputdiv"><b>电话号码</b><input name="tel" type="text" class="inputtext"></div>
                <div class="inputdiv"><b>邮箱</b><input name="email" type="text" class="inputtext"></div>
                <div class="inputdiv"><b>地址</b><input name="address" type="text" class="inputtext"></div>
                <div class="inputdiv"><b>留言内容</b><textarea name="content" class="inputtext areatext"></textarea></div>
                <input name="table" type="hidden" value="guestbook">
                <input name="token" type="hidden" value=" 665f135965d66819a300dd4c16dadce9 ">
                <input type="submit" value="提交" class="subbtn">
            </form>
        </div>
    </div>
  </div>
</div>

<!-- 底部 开始 -->
<?php
	include "footer.php";
?>
<!-- 底部 结束 -->
<a data-cltversion="2.4.6" data-cltsource="80016" data-cltuuid="extXs8zJtPmN3QMqw5wnaj8JlgMbQHOsrnV3" data-cltats="4" href="javascript:" id="yht-info-explugin" style="display: none;"></a></body></html>