<!DOCTYPE html>
<!-- saved from url=(0033)http://www.hnxhqh.com/page-7.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>上海墙绘,上海艺路人墙绘-联系我们</title>
  <meta name="keywords" content="上海墙绘,上海艺路人墙绘,上海饭店墙绘,上海幼儿园墙绘">
  <meta name="description" content="艺路人墙绘艺术设计中心主要为高档宾馆酒店,写字楼,幼儿园,古建筑等楼堂馆所进行墙绘工作">
<link href="./css/main.css" rel="stylesheet" type="text/css">
<script src="./js/jQuery1.7.2.js.下载" type="text/javascript"></script>
</head>
<body>
<!-- 头部 开始 -->

<?php
  $page = "lianxi";
  include "head.php";
?>
<!-- 头部 结束 -->
<div class="clear"></div><!-- banner 开始 -->
<div class="fullSlide banner_contact"></div>
<!-- banner 结束 -->

<div class="index">
  <div class="mainnav float_left">
    <!-- 左侧导航 开始 -->
<!-- 左侧导航 结束 -->

<!-- 左侧轮播 开始 -->
<?php
  include "left.html";
?>
<!-- 左侧轮播 结束 -->

<!-- 联系方式 开始 -->

<!-- 联系方式 结束 -->  </div>
  <div class="index_left float_right">
    <div class="main_title"><b>首页 &gt; <span>联系我们</span></b></div>
    <div class="editor">
		<div class="infotext info_border">
        	<div class="infotitle">在线留言</div>
            <form action="http://www.hnxhqh.com/index.php?r=GooCms/Form/push" method="post" autocomplete="off">
                <div class="inputdiv"><b>电话号码</b><input name="tel" type="text" class="inputtext"></div>
                <div class="inputdiv"><b>邮箱</b><input name="email" type="text" class="inputtext"></div>
                <div class="inputdiv"><b>地址</b><input name="dizhi" type="text" class="inputtext"></div>
                <div class="inputdiv"><b>留言内容</b><textarea name="content" class="inputtext areatext"></textarea></div>
                <input name="table" type="hidden" value="guestbook">
                <input name="token" type="hidden" value=" 7943ddc5754ff9c4d5123a2ed2aff5a4 ">
                <input type="submit" value="提交" class="subbtn">
            </form>
        </div>
        <div class="infotext info_border">
        	<div class="infotitle">人才招聘</div>
        	<!-- <img src="./联系我们 - 熙虎墙绘艺术设计中心 -_files/contact.png"> -->
            <div class="contact_tip"><div class="tips"><p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;"><span>招聘：</span></span><span style="font-family:宋体;font-size:10.5000pt;"></span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;"><span>1、</span></span><span style="font-family:宋体;font-size:10.5000pt;"><span>画师学徒</span></span><span style="font-family:宋体;font-size:10.5000pt;"></span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;"><span>2、</span></span><span style="font-family:宋体;font-size:10.5000pt;"><span>监理画师</span></span><span style="font-family:宋体;font-size:10.5000pt;"></span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;"><span>3、</span></span><span style="font-family:宋体;font-size:10.5000pt;"><span>高级画师</span></span><span style="font-family:宋体;font-size:10.5000pt;"></span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;"><span>岗位职责：</span></span><span style="font-family:宋体;font-size:10.5000pt;"></span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;"><span>1、</span></span><span style="font-family:宋体;font-size:10.5000pt;"><span>画师学徒要求对墙绘事业充满热情，愿意学习墙绘技法</span>,<span>有一定的美术基础者优先。</span></span><span style="font-family:宋体;font-size:10.5000pt;"></span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;"><span>2、</span></span><span style="font-family:宋体;font-size:10.5000pt;"><span>监理画师要求发自内心热爱绘画行业，有一年及以上从业经验，能够协助带队画师完成工程墙绘，并协调公司与现场相关事宜。</span></span><span style="font-family:宋体;font-size:10.5000pt;"></span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;"><span>3、</span></span><span style="font-family:宋体;font-size:10.5000pt;"><span>高级画师要求有两年及以上从业经验，能够独立刻画画面细节，熟练掌握绘画技法，能按图施工达到</span>90%<span>的相似度，模仿能力强，注重画面情感表达。</span></span><span style="font-family:宋体;font-size:10.5000pt;"></span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;">&nbsp;</span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;"><span>有意者可将作品发送到邮箱：</span></span><span><a href="mailto:515660506@qq.com"><u><span class="15" style="font-family:宋体;color:#0000FF;text-decoration:underline;">515660506@qq.com</span></u></a></span><span style="font-family:宋体;font-size:10.5000pt;"></span>
</p>
<p class="MsoNormal">
	<span style="font-family:宋体;font-size:10.5000pt;"><span>薪资待遇当面详谈</span></span><span style="font-family:宋体;font-size:10.5000pt;"></span>
</p></div></div>
        </div>
     <!--    <div class="infotext">
        	<div class="infotitle">公司规模</div>
            <div style="width:66%; position:absolute; left:0; top:70px; z-index:3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#f60;">熙虎墙绘</span>艺术设计中心隶属于郑州大旗装饰设计工程有限公司成立于2010年，是河南地区墙绘专业领域成长最迅速，最令人兴奋的品牌。自创立到现在，我们始终以创新与商业价值的最大化为宗旨；通过超前的理念，不断的探询、研究、创造，并不断突破，持之以恒地赋予品牌新的力量和活力。&nbsp;</div>
            <img src="/themes/xihuqianghui/images/contact1.png">
        </div> -->
    </div>
  </div>
</div>

<!-- 底部 开始 -->
<?php
  include "footer.php";
?>
<!-- 底部 结束 -->

</body></html>