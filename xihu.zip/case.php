<!DOCTYPE html>
<!-- saved from url=(0031)http://www.hnxhqh.com/case.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
	<title>上海墙绘,上海艺路人墙绘-经典案例</title>
	<meta name="keywords" content="上海墙绘,上海艺路人墙绘,上海饭店墙绘,上海幼儿园墙绘">
	<meta name="description" content="上海艺路人墙绘艺术设计中心主要为高档宾馆酒店,写字楼,幼儿园,古建筑等楼堂馆所进行墙绘工作">
<link href="./css/main.css" rel="stylesheet" type="text/css">
<script src="./js/hm.js"></script><script src="./js/jQuery1.7.2.js" type="text/javascript"></script>
</head>

<body>
<!-- 头部 开始 -->
<?php
	$page = "case";
	include "head.php";
?>
<!-- 头部 结束 -->
<div class="clear"></div><!-- banner 开始 -->
<div class="fullSlide banner_case"></div>
<!-- banner 结束 -->

<div class="index">
  <div class="mainnav float_left"> 
    <!-- 左侧导航 开始 -->
<!-- 左侧导航 结束 -->

<!-- 左侧轮播 开始 -->
<?php
	include "left.html";
?>

<!-- 左侧轮播 结束 -->

<!-- 联系方式 开始 -->

<!-- 联系方式 结束 -->  </div>
  <div class="index_left float_right">
    <div class="main_title"><b>首页 &gt; <span>经典案例</span></b></div>
    <div class="editor">
    	<div class="casebox one1" style="display: block;">
            <div class="infotitle info_border">新农村墙绘</div>
            <ul class="caselist">
            	                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong1.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong1_ico.jpg"><div class="anlihover"></div>
                    <p>新农村墙绘1</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong2.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong2_ico.jpg"><div class="anlihover"></div>
                    <p>新农村墙绘2</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong3.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong3_ico.jpg"><div class="anlihover"></div>
                    <p>新农村墙绘3</p></a></li>
                                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong4.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong4_ico.jpg"><div class="anlihover"></div>
                    <p>新农村墙绘4</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong5.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong5_ico.jpg"><div class="anlihover"></div>
                    <p>新农村墙绘5</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong6.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/nong6_ico.jpg"><div class="anlihover"></div>
                    <p>新农村墙绘6</p></a></li>
                                            </ul>
            <div class="infotitle info_border">3D立体画</div>
            <ul class="caselist">
                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d1.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d1.jpg"><div class="anlihover"></div>
                    <p>示例1</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d2.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d2.jpg"><div class="anlihover"></div>
                    <p>示例2</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d3.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d3.jpg"><div class="anlihover"></div>
                    <p>示例3</p></a></li>
                                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d4.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d4.jpg"><div class="anlihover"></div>
                    <p>示例4</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d5.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d5.jpg"><div class="anlihover"></div>
                    <p>示例5</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d6.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/3d6.jpg"><div class="anlihover"></div>
                    <p>示例6</p></a></li>
                                            </ul>
            <div class="infotitle info_border">娱乐场所墙绘</div>
            <ul class="caselist">
                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/yu1.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/yu1.jpg"><div class="anlihover"></div>
                    <p>示例1</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/yu2.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/yu2.jpg"><div class="anlihover"></div>
                    <p>示例2</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/yu3.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/yu3.jpg"><div class="anlihover"></div>
                    <p>示例3</p></a></li>
                                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/yin4.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/yin4.jpg"><div class="anlihover"></div>
                    <p>示例4</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/yu5.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/yu5.jpg"><div class="anlihover"></div>
                    <p>示例5</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/yu6.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/yu6.jpg"><div class="anlihover"></div>
                    <p>示例6</p></a></li>
                                            </ul>
          
        </div>
        <div class="casebox one2" style="display: none;">
            
              <div class="infotitle info_border">家装墙绘</div>
            <ul class="caselist">
                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi1.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi1.jpg"><div class="anlihover"></div>
                    <p>中式家装背景墙</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi2.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi2.jpg"><div class="anlihover"></div>
                    <p>客厅 壁画</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi3.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi3.jpg"><div class="anlihover"></div>
                    <p>客厅 壁画</p></a></li>
                                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi4.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi4.jpg"><div class="anlihover"></div>
                    <p>沙发 背景墙</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi5.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi5.jpg"><div class="anlihover"></div>
                    <p>卧室 壁画</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi6.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shi6.jpg"><div class="anlihover"></div>
                    <p>客房 壁画</p></a></li>
                                            </ul>
            <div class="infotitle info_border">古建彩绘</div>
            <ul class="caselist">
                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao5.png" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao5.png"><div class="anlihover"></div>
                    <p>延古寺彩绘</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao4.jpg" target="_blank"> <img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao4.jpg"><div class="anlihover"></div>
                    <p>紫云寺大雄宝殿</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao2.png" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao2.png"><div class="anlihover"></div>
                    <p>寿光宁国寺</p></a></li>
                                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao1.png" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao1.png"><div class="anlihover"></div>
                    <p>黄梅妙乐寺天王殿</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao3.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao3.jpg"><div class="anlihover"></div>
                    <p>宗泽园</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao6.png" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/miao6.png"><div class="anlihover"></div>
                    <p>净影寺大雄宝殿</p></a></li>
                                            </ul>
         <!--    <div class="infotitle info_border">家装墙绘</div> -->
            <ul class="caselist">
                            </ul>
        </div>
        <div class="casebox one3" style="display: none;">
            <div class="infotitle info_border">山水画</div>
            <ul class="caselist">
                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan1.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan1.jpg"><div class="anlihover"></div>
                    <p>示例1</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan2.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan2.jpg"><div class="anlihover"></div>
                    <p>示例2</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan3.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan3.jpg"><div class="anlihover"></div>
                    <p>示例3</p></a></li>
                                                                <li class="noleft"><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan4.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan4.jpg"><div class="anlihover"></div>
                    <p>示例4</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan5.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan5.jpg"><div class="anlihover"></div>
                    <p>示例5</p></a></li>
                                                                <li><a href="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan6.jpg" target="_blank"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/case/shan6.jpg"><div class="anlihover"></div>
                    <p>示例6</p></a></li>
                                            </ul>
        </div>
        
        <div class="pagelist">
            <span id="one1" class="current">1</span>
            <span id="one2" class="">2</span>
            <span id="one3" class="">3</span>
        </div>
        <script type="text/javascript">
			$(document).ready(function(){
				$(".pagelist span:first").addClass("current");
				$(".pagelist span").click(function(){
					$(".pagelist span").removeClass("current");
					$(this).addClass("current");
					$(".casebox").hide();
					$("."+ $(this).attr("id")).show();
				});
			});
		</script>
    </div>
  </div>
</div>

<!-- 底部 开始 -->
<?php
	include "footer.php";
?>
<!-- 底部 结束 -->

<a data-cltversion="2.4.6" data-cltsource="80016" data-cltuuid="extXs8zJtPmN3QMqw5wnaj8JlgMbQHOsrnV3" data-cltats="4" href="javascript:" id="yht-info-explugin" style="display: none;"></a></body></html>