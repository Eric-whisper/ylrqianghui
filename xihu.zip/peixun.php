<!DOCTYPE html>
<!-- saved from url=(0033)http://www.hnxhqh.com/depict.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
  <title>墙绘培训-上海艺路人墙绘</title>
  <meta name="keywords" content="上海墙绘,上海艺路人墙绘,上海饭店墙绘,上海幼儿园墙绘">
  <meta name="description" content="艺路人墙绘艺术设计中心主要为高档宾馆酒店,写字楼,幼儿园,古建筑等楼堂馆所进行墙绘工作">
<link href="./css/main.css" rel="stylesheet" type="text/css">
<script src="./js/hm.js"></script><script src="./jsas/jQuery1.7.2.js" type="text/javascript"></script>

<body>
<!-- 头部 开始 -->
<?php
  $page = "peixun";
	include "head.php";
?>

<!-- 头部 结束 -->
<div class="clear"></div><script language="VBScript"><!--

//--></script><!-- banner 开始 -->
<div class="fullSlide banner_depict"></div>
<!-- banner 结束 -->

<div class="index">
  <div class="mainnav float_left"> 
    <!-- 左侧导航 开始 -->

<!-- 左侧导航 结束 -->

<!-- 左侧轮播 开始 -->
<?php
  include "left.html";
?>
<!-- 左侧轮播 结束 -->

<!-- 联系方式 开始 -->

<!-- 联系方式 结束 -->  </div>
  <div class="index_left float_right">
    <div class="main_title"><b>首页 &gt; <span>墙绘培训</span></b></div>
    <div class="editor">
        <div class="infotext">
            <p>
	<span style="white-space:normal;color:#FF6600;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span>
</p>
<p>
	<img src="https://ylr.oss-cn-beijing.aliyuncs.com/images/pre1.png" alt=""> 
</p>        </div>
		<div class="infotext">
        	<div class="infotitle">在线留言</div>
            <div class="message_tip"><span>&gt; 我们非常重视您的意见并将在24小时内给您回复</span></div>
            <form>
                <div class="inputdiv"><b>电话号码</b><input type="text" class="inputtext"></div>
                <div class="inputdiv"><b>邮箱</b><input type="tel" class="inputtext"></div>
                <div class="inputdiv"><b>地址</b><input type="email" class="inputtext"></div>
                <div class="inputdiv"><b>留言内容</b><textarea class="inputtext areatext"></textarea></div>
                <input type="submit" value="提交" class="subbtn">
            </form>
        </div>
    </div>
  </div>
</div>

<!-- 底部 开始 -->
<?php
  include "footer.php";
?>

</body></html>