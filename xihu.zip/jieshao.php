<!DOCTYPE html>
<!-- saved from url=(0033)http://www.hnxhqh.com/page-1.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
	<title>上海墙绘,上海艺路人墙绘-介绍</title>
	<meta name="keywords" content="上海墙绘,上海艺路人墙绘,上海饭店墙绘,上海幼儿园墙绘">
	<meta name="description" content="艺路人墙绘艺术设计中心主要为高档宾馆酒店,写字楼,幼儿园,古建筑等楼堂馆所进行墙绘工作">
<link href="./css/main.css" rel="stylesheet" type="text/css">
<script src="./js/hm.js"></script><script src="./js/jQuery1.7.2.js" type="text/javascript"></script>
</head>

<body>
<!-- 头部 开始 -->
<?php
    $page = "jieshao";
	include "head.php";
?>

<!-- 头部 结束 -->
<div class="clear"></div><!-- banner 开始 -->
<div class="fullSlide banner_info"></div>
<!-- banner 结束 -->

<div class="index">
  <div class="mainnav float_left">
    <!-- 左侧导航 开始 -->

<!-- 左侧导航 结束 -->

<!-- 左侧轮播 开始 -->
<?php
    include "left.html";
?>
<!-- 左侧轮播 结束 -->

<!-- 联系方式 开始 -->

<!-- 联系方式 结束 -->  </div>
  <div class="index_left float_right">
    <div class="main_title"><b>首页 &gt; <span>公司介绍</span></b></div>
    <div class="editor">
        <div class="infotext info_border">
        	<img src="https://ylr.oss-cn-beijing.aliyuncs.com/images/jieshao1.png" style="margin-right:20px;float:left;"> 
<p>
	<span style="color:#f60;">
	</span></p><p class="MsoNormal" style="line-height:22.5pt;">
		<span style="font-family:宋体;color:#000000;"><span style="color:#E56600;">上海艺路人彩绘文化有限公司</span>成立于</span><span style="color:#000000;">2010年， 本中心成立近七年来，资金投入不断，团队不断壮大，技术一直创新。我们一贯以原创的设计方案，热情的服务态度，以及周到的售后服务来树立我们的形象，通过超前的理念，不断的探询、研究、创造，并不断突破，持之以恒地赋予品牌新的力量和活力。</span><o:p></o:p>
	</p>
	<p class="MsoNormal" style="line-height:22.5pt;">
		<span style="color:#000000;">&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="font-family:宋体;color:#000000;">艺路人墙绘艺术设计中心主要为高档宾馆酒店、写字楼等楼堂馆所，提供订制油画、国画、墙体壁画、真丝壁画、立体画、隐形画</span> <span style="font-family:宋体;color:#000000;">古建彩绘等整体设计及施工。我们用艺术创意和认真细致的服务，为客户呈现完美的作品，用优质的作品帮助客户深化企业文化内涵，塑造优质的品牌形象。</span><o:p></o:p>
	</p>
	<p class="MsoNormal" style="line-height:22.5pt;">
		<span style="color:#000000;">&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="font-family:宋体;color:#000000;">艺路人墙绘的团队汇聚了业内资深、精英人士，并且和国内各知名艺术院校深度合作成立墙体彩绘古建彩绘专业培训机构，帮助并培养了一大批青年设计师和墙绘师。保证了我公司人才资源的连续性和专业性。共同携手让创意改变生活！</span><o:p></o:p>
	</p>
<span style="color:#000000;"></span>
<p></p>        </div>
       
        <div class="infotext info_border">
        	<div class="infotitle">我们的团队</div>
            <div style="width:100%; margin-bottom:10px;"><p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#f60;">艺路人彩绘<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">的团队汇聚了业内资深、精英人士，并且和国内各知名大专院校深度合作，帮助并培养了一大批青年设计师和墙绘师。保证了我公司人才资源的连续性和专业性。同时，在与知名高校的合作中提升业务水平和技术实力。</span></span>
</p>
<p>
	<span style="color:#f60;"><span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/images/jieshao2.jpg" alt=""><br>
</span></span>
</p></div>
            <!-- <img src="/themes/xihuqianghui/images/info02.jpg"> -->
        </div>
        <div class="infotext">
        	<div class="infotitle">案例展示</div>
        	<div style="width:100%; margin-bottom:10px;"><p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#f60;">艺路人彩绘<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">主要为高档宾馆酒店、咖啡馆<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、餐厅<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、网咖<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、酒吧KTV<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、卧室<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、客厅<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、</span></span></span></span>幼儿园</span></span><span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、</span>写字楼等楼堂馆所，以及各种高端仿古建筑，提供墙体彩绘、壁画、隐形画、立体画、古建彩画的整体设计及施工。</span></span>
</p>
<p>
	<span style="color:#f60;"><span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;"><img src="https://ylr.oss-cn-beijing.aliyuncs.com/images/jieshao3.jpg" alt=""><br>
</span></span> 
</p></div>
            <!-- <img src="/themes/xihuqianghui/images/info1.png"> -->
        </div>
    </div>
  </div>
</div>

<!-- 底部 开始 -->
<?php
	include "footer.php";
?>
<!-- 底部 结束 -->

<a data-cltversion="2.4.6" data-cltsource="80016" data-cltuuid="extXs8zJtPmN3QMqw5wnaj8JlgMbQHOsrnV3" data-cltats="4" href="javascript:" id="yht-info-explugin" style="display: none;"></a></body></html>