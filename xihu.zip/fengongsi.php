<!DOCTYPE html>
<!-- saved from url=(0035)http://www.hnxhqh.com/painting.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
	<title>上海墙绘,上海艺路人墙绘-分公司</title>
	<meta name="keywords" content="上海墙绘,上海艺路人墙绘,上海饭店墙绘,上海幼儿园墙绘">
	<meta name="description" content="艺路人墙绘艺术设计中心主要为高档宾馆酒店,写字楼,幼儿园,古建筑等楼堂馆所进行墙绘工作">
<link href="./css/main.css" rel="stylesheet" type="text/css">
<script src="./js/hm.js"></script><script src="./js/jQuery1.7.2.js" type="text/javascript"></script>
</head>

<body>
<!-- 头部 开始 -->
	<?php
		$page = "fengongsi"
 		include "head.php"; 
	?>

<!-- 头部 结束 -->

<div class="fullSlide banner_depict"></div>
<!-- banner 结束 -->

<div class="index">
    <!-- 左侧导航 开始 -->

<!-- 左侧导航 结束 -->

<!-- 左侧轮播 开始 -->
<?php
	include "left.html";
?>
<!-- 左侧轮播 结束 -->

<!-- 联系方式 开始 -->

 </div>
  <div class="index_left float_right">
    <div class="main_title"><b>首页 &gt; <span>分公司介绍</span></b></div>
    <div class="editor">
    	<div class="infotext info_border"><img src="./prefab/22ea73316ad8323820d09f2d4e4d8fe4.png" style="margin-right:20px;float:left;"> 
<p>
	<span style="font-size:10px;white-space:normal;line-height:2;color:#999999;">艺路人墙绘北京分公司：北京市昌平区天通苑 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 联系人：钱信旭</span><br style="white-space:normal;">
<span style="font-size:10px;white-space:normal;line-height:2;color:#999999;">艺路人墙绘上海分公司：上海市高新区紫阳大道 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;联系人：钱星旭</span><br style="white-space:normal;">
<span style="font-size:10px;white-space:normal;line-height:2;color:#999999;">艺路人墙绘郑州分公司：郑州市高新区科学大道 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;联系人：钱星旭</span><br style="white-space:normal;">
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:12px;line-height:1.5;font-family:宋体;color:#000000;"><br>
</span> 
</p>
<p>
	<span style="font-size:10px;white-space:normal;line-height:2;color:#999999;"><br>
</span> 
</p>
<p>
	<br>
</p>
<p>
	<br>
</p>
<p class="MsoNormal">
	<br>
</p>
<p class="MsoNormal">
	<br>
</p>
<p class="MsoNormal">
	<br>
</p>
<p>
	<br>
</p></div>
        <div class="infotext">
        	<div class="infotitle">案例展示</div>
            <div style="width:66%; height:85px; overflow:hidden; position:absolute; left:0; top:70px; z-index:3;"><p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#f60;">艺路人墙绘<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">主要为高档宾馆酒店、咖啡馆<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、餐厅<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、网咖<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、酒吧KTV<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、卧室<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、客厅<span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、</span></span></span></span>幼儿园</span></span><span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;">、</span>写字楼等楼堂馆所，以及各种高端仿古建筑，提供墙体彩绘、壁画、隐形画、立体画、古建彩画的整体设计及施工。</span></span>
</p>
<p>
	<span style="color:#f60;"><span style="color:#333333;font-family:&#39;Microsoft YaHei&#39;, Tahoma, Verdana, Simsun;line-height:27px;white-space:normal;background-color:#FFFFFF;"><img src="./分jieshao/ddb09feb588b3843dc569d11ce83bec6.jpg" alt=""><br>
</span></span> 
</p></div>
            <img src="./分jieshao/painting.jpg">
        </div>
    </div>
  </div>
</div>

<!-- 底部 开始 -->
<?php
	include "footer.php";
?>
<!-- 底部 结束 -->

<a data-cltversion="2.4.6" data-cltsource="80016" data-cltuuid="extXs8zJtPmN3QMqw5wnaj8JlgMbQHOsrnV3" data-cltats="4" href="javascript:" id="yht-info-explugin" style="display: none;"></a></body></html>